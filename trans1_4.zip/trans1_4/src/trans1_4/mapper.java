package trans1_4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		int m = c.getConfiguration().getInt("Month", 01);
		String month = inpv.getmonth();
		//String mon = String.valueOf(m);
		int mon =Integer.parseInt(month);
		
		double val = inpv.getAmt();
		if(m==mon)
		{
		   c.write(new Text(Integer.toString(mon)),new DoubleWritable(val));
	}
}
}
