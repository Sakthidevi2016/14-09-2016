package trans1_4;

import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Scanner src = new Scanner(System.in);
		Configuration conf = new Configuration();
		FileSystem hdfs = FileSystem.get(conf);
		System.out.println("Enter the month in mm format");
		int month = src.nextInt();
		conf.setInt("Month", month);
		Job j = new Job(conf, "Output");
		j.setJarByClass(driver.class);
		j.setMapperClass(mapper.class);
		j.setReducerClass(reducer.class);
		j.setNumReduceTasks(1);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(DoubleWritable.class);
		j.setInputFormatClass(inputformat.class);
	
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path (args[1]));

		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
			hdfs.delete(newpath,true);
		}
		
		Path localfilepath = new Path("/home/hduser/InputFormat_Trans4");
		if(j.waitForCompletion(true)){
			hdfs.copyToLocalFile(newpath, localfilepath);
		}
			System.exit(j.waitForCompletion(true)?0:1);
		}

}
