package trans1_3;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		int userid = c.getConfiguration().getInt("User id", 4000001);
		String uid = inpk.getid();
		int i=Integer.parseInt(uid);
		if(i==userid)
		{
		 		    c.write(new Text(inpk.getid()),new DoubleWritable(inpv.getAmt()));
 	   }
    }
}
