package task7;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class task7partitioner extends Partitioner<Text, IntWritable> {

	@Override
	public int getPartition(Text arg0, IntWritable arg1, int arg2) {
		String arg = arg0.toString();
		if(arg.contains("ERROR"))
			return 0;
		else if(arg.contains("DEBUG"))
			return 1;
		else if(arg.contains("FATAL"))
			return 2;
		else if(arg.contains("INFO"))
			return 3;
		else if(arg.contains("TRACE"))
			return 4;
		else 
			return 5;
		}

}