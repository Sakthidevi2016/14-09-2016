package test;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myCombiner extends Reducer<Text, IntWritable, Text, IntWritable> {
	public void reduce(Text inpK, IntWritable inpV, Context c) throws IOException, InterruptedException{
		String name = inpK.toString();
		//if(inpV.get()== 170)
			//c.write(inpK, inpV);
		if(name.equalsIgnoreCase("oliver"))
			c.write(inpK, inpV);
	}

}
