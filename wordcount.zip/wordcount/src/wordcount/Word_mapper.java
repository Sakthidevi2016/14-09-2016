package wordcount;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Word_mapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value = inpv.toString();
	Text outk = new Text();
	IntWritable outv = new IntWritable(1);
	StringTokenizer token = new StringTokenizer(value);
	while(token.hasMoreTokens()){
		outk.set(token.nextToken());
		c.write(outk, outv);
	}
	
	}
}


