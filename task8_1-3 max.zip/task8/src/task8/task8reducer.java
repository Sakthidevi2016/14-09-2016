package task8;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task8reducer extends Reducer<Text, Text, Text, Text>{
		public void reduce(Text InpK, Iterable<Text> InpV, Context c) throws IOException, InterruptedException{
			/*int max=0,value=0;
			String module=" ";
			for(Text each: InpV){
				String[] eachVal = each.toString().split(":");
				value=Integer.parseInt(eachVal[1]);
				if(max<value){
					max=value;
					module=eachVal[0];
				}
						
		}*/
			int max1 = Integer.MIN_VALUE;
			int max2 = Integer.MIN_VALUE;
			int max3 = Integer.MIN_VALUE;
			int value = 0;
			String max1_module = " ";
			String max2_module = " ";
			String max3_module = " ";
			for(Text each : InpV){
				String[] eachVal = each.toString().split(":");
				value=Integer.parseInt(eachVal[1]);
	            if(value>max1)
	            {
	            	max2=max1;
	            	max1=value;
	            	max2_module = max1_module;
	            	max1_module = eachVal[0];
	            }
	            else if(value>max2)
	            {
	            	max3=max2;
	            	max2=value;
	                max3_module = max2_module;
	            	max2_module = eachVal[0];
	            }
	            /*else if(value>max3)
	            {
	            	max3=value;
	              	            }*/
	            	
			}
			c.write(new Text(max1_module+" "+max2_module+" "+max3_module), new Text(max1+" "+max2+" "+max3));
	}
	}
