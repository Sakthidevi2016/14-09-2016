package sample;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value = inpv.toString();
	String eachVal[] =value.split(" ");
	Text outK = new Text(eachVal[0]);
	IntWritable outV = new IntWritable(1);
	c.write(outK, outV);
	}

}
