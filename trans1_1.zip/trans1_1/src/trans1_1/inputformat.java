package trans1_1;

import java.io.IOException;

import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

public class inputformat extends FileInputFormat<key, value> {

	@Override
public RecordReader<key, value> createRecordReader(InputSplit arg0, TaskAttemptContext arg1)
		throws IOException, InterruptedException {
	// TODO Auto-generated method stub
	return new recordreader();
}

}
