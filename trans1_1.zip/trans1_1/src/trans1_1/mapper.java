package trans1_1;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		Double minamt = (double) c.getConfiguration().getInt("Amount", 160);
		Double amt = inpv.getAmt();
 	   if(amt>minamt)
 	   {
 		    c.write(new Text(inpk.getid()),new DoubleWritable(inpv.getAmt()));
 	   }
    }
}
