package task8;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task8reducer extends Reducer<Text, Text, Text, IntWritable>{
		public void reduce(Text InpK, Iterable<Text> InpV, Context c) throws IOException, InterruptedException{
			int max=0,value=0;
			String module=" ";
			for(Text each: InpV){
				String[] eachVal = each.toString().split(":");
				value=Integer.parseInt(eachVal[1]);
				if(max<value){
					max=value;
					module=eachVal[0];
				}
			
			
		}
			c.write(new Text(module), new IntWritable(max));
	}
	}
